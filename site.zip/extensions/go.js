document.write('<script type="text/javascript" src="../release/go.js"></script>');
